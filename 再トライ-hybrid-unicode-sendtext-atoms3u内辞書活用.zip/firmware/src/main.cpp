#include <Arduino.h>
#include <USB.h>
#include <USBHIDKeyboard.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include "FS.h"
#include "SPIFFS.h"
#include "freertos/queue.h"

// TinyUSB マウント監視API
extern "C" bool tud_mounted(void);

// ============================================================================
// ハードウェア設定・ピン定義 (M5Stack AtomS3U: ESP32-S3FN8, 8MB Flash, No PSRAM)
// ============================================================================
#define RGB_LED_PIN         35  // 内蔵WS2812フルカラーLED
#define FRONT_BTN_PIN       41  // 正面プッシュスイッチ (Active LOW: 押下時にGND)

// BLE UUID定義 (DrVoice どんぐり君 アプリと完全一致)
#define SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"

// プロトコル制約
#define MAX_PAYLOAD_SIZE    4096
#define MAX_PACKETS         16
#define MAX_PACKET_LEN      256
#define BLE_CHUNK_SIZE      (8 + MAX_PACKET_LEN)
#define BLE_QUEUE_SIZE      32
#define RX_TIMEOUT_MS       1500  // 受信タイムアウト (1.5秒で迅速に再送要求)
#define MAX_RETRY_COUNT     3

// 安全なキーコード定義 (USBHIDKeyboard準拠)
#ifndef KEY_RETURN
#define KEY_RETURN 0xB0
#endif
#ifndef KEY_ESC
#define KEY_ESC 0xB1
#endif
#ifndef KEY_BACKSPACE
#define KEY_BACKSPACE 0xB2
#endif
#ifndef KEY_TAB
#define KEY_TAB 0xB3
#endif
#ifndef KEY_LEFT_SHIFT
#define KEY_LEFT_SHIFT 0x81
#endif
#ifndef KEY_F5
#define KEY_F5 0xC6
#endif
#ifndef KEY_F6
#define KEY_F6 0xC7
#endif
#ifndef KEY_F7
#define KEY_F7 0xC8
#endif
#ifndef KEY_F10
#define KEY_F10 0xCB
#endif

// ============================================================================
// 型定義・プロトコル構造体
// ============================================================================
enum SystemState {
  STATE_USB_NOT_READY,
  STATE_WAITING_BLE,
  STATE_BLE_CONNECTED,
  STATE_RECEIVING,
  STATE_READY_TO_TYPE,  // 受信・CRC完全検証完了（黄色LED点灯・ボタン押下待機）
  STATE_TYPING,         // USB送出中（赤色LED点灯）
  STATE_ERROR
};

enum DispatchMode {
  MODE_RAW_ASCII = 0,        // 患者ID、半角英数字直接送出
  MODE_IME_ROMAJI = 1,       // クライアント側IME協調ローマ字モード (<IME_ON>等タグ)
  MODE_HYBRID_UNICODE = 2    // 自然文節・高精度IME協調パイプライン
};

#pragma pack(push, 1)
// 8バイト初期化フレーム
struct SessionInitHeader {
  uint16_t sessionId;
  uint8_t  totalPackets;
  uint16_t totalBytes;
  uint16_t totalCrc16;
  uint8_t  reserved;
};

// 8バイトスロットパケットヘッダ
struct SlotHeader {
  uint16_t sessionId;
  uint8_t  seqNo;
  uint8_t  mode;
  uint16_t payloadLen;
  uint16_t chunkCrc16;
};

// ----------------------------------------------------------------------------
// SPIFFS固定長バイナリ辞書構造体 (Zero-RAM Binary Search Specification)
// ----------------------------------------------------------------------------
// 1. /kanji_f5.bin ヘッダ (8バイト)
struct KanjiHeader {
  char     magic[4];       // "KANJ"
  uint16_t count;          // レコード件数 (LE)
  uint16_t recordSize;     // レコード長 (8バイト)
};

// /kanji_f5.bin レコード (8バイト固定長 / UTF-8昇順ソート済み)
struct KanjiRecord {
  char     utf8[4];        // UTF-8文字バイト列 (Nullパディング)
  uint16_t unicode;        // Unicode (UCS-2 / UTF-16) 16進値 (LE)
  uint8_t  flag;           // 属性フラグ (0x01: F5強制)
  uint8_t  padding;        // パディング
};

// 2. /med_terms.bin ヘッダ (16バイト)
struct TermHeader {
  char     magic[4];       // "TERM"
  uint32_t count;          // レコード件数 (LE)
  uint16_t recordSize;     // レコード長 (32バイト)
  uint8_t  reserved[6];    // 予約領域 (Null)
};

// /med_terms.bin レコード (32バイト固定長 / FNV-1a 32bitハッシュ昇順ソート済み)
struct MedTermRecord {
  uint32_t hash;           // FNV-1a 32bitハッシュ (LE)
  uint8_t  mode;           // 打鍵モード (1: Space漢字変換, 2: F7カタカナ強制, 3: 半角F10)
  uint8_t  romajiLen;      // ローマ字バイト長
  char     romaji[26];     // ヘボン式ローマ字列 (Nullパディング)
};
#pragma pack(pop)

struct BleQueueItem {
  uint16_t length;
  uint8_t  data[BLE_CHUNK_SIZE];
};

struct PacketSlot {
  bool     received;
  uint16_t len;
  uint8_t  payload[MAX_PACKET_LEN];
};

struct MessageContext {
  uint16_t   sessionId;
  uint8_t    totalPackets;
  uint8_t    receivedCount;
  uint16_t   expectedTotalBytes;
  uint16_t   expectedTotalCrc;
  uint8_t    mode;
  size_t     actualTotalBytes;
  uint32_t   lastActivityTime;
  uint8_t    retryAttempts;
  PacketSlot slots[MAX_PACKETS];
  char       assembledBuffer[MAX_PAYLOAD_SIZE + 1];
};

// ============================================================================
// グローバル変数
// ============================================================================
USBHIDKeyboard Keyboard;
static BLEServer *pBleServer = nullptr;
static BLECharacteristic *pTxRxCharacteristic = nullptr;
static QueueHandle_t bleQueue = nullptr;

static SystemState currentState = STATE_WAITING_BLE;
static bool isBleConnected = false;
static bool lastUsbState = false;
static bool spiffsMounted = false;

static MessageContext currentMsg;

// ============================================================================
// CRC-16/CCITT-FALSE 計算 (Poly: 0x1021, Init: 0xFFFF)
// ============================================================================
uint16_t calculateCrc16(const uint8_t* data, size_t length) {
  uint16_t crc = 0xFFFF;
  for (size_t i = 0; i < length; i++) {
    crc ^= ((uint16_t)data[i] << 8);
    for (uint8_t bit = 0; bit < 8; bit++) {
      if (crc & 0x8000) {
        crc = (crc << 1) ^ 0x1021;
      } else {
        crc = (crc << 1);
      }
    }
  }
  return crc;
}

static inline uint16_t readUint16LE(const uint8_t* buf) {
  return (uint16_t)buf[0] | ((uint16_t)buf[1] << 8);
}

// ============================================================================
// FNV-1a 32-bit ハッシュ計算 (オフセット: 0x811C9DC5, 素数: 0x01000193)
// ============================================================================
uint32_t calculateFnv1a32(const char* data, size_t len) {
  uint32_t hash = 0x811C9DC5;
  for (size_t i = 0; i < len; i++) {
    hash ^= (uint8_t)data[i];
    hash = hash * 0x01000193;
  }
  return hash;
}

// UTF-8文字長判定
static inline size_t getUtf8CharLen(uint8_t c) {
  if ((c & 0x80) == 0) return 1;
  if ((c & 0xE0) == 0xC0) return 2;
  if ((c & 0xF0) == 0xE0) return 3;
  if ((c & 0xF8) == 0xF0) return 4;
  return 1;
}

// ============================================================================
// ハードウェア制御 (WS2812 RGB LED) - 変化時のみ書き込んで割込停止を抑止
// ============================================================================
void setLedColor(uint8_t r, uint8_t g, uint8_t b) {
  static uint8_t curR = 255, curG = 255, curB = 255;
  if (r == curR && g == curG && b == curB) return;
  curR = r; curG = g; curB = b;
  neopixelWrite(RGB_LED_PIN, r, g, b);
}

// ============================================================================
// 医療情報セキュリティ: 最適化抑止型ゼロクリア
// ============================================================================
void secureWipeMessageContext() {
  volatile uint8_t* p = (volatile uint8_t*)&currentMsg;
  size_t n = sizeof(MessageContext);
  while (n--) {
    *p++ = 0;
  }
}

// FreeRTOSキューの完全排出（打鍵完了時・切断時・明示的WIPE時のみ実行）
void drainBleQueue() {
  if (bleQueue == nullptr) return;
  BleQueueItem item;
  while (xQueueReceive(bleQueue, &item, 0) == pdTRUE) {
    volatile uint8_t* p = (volatile uint8_t*)&item;
    size_t n = sizeof(BleQueueItem);
    while (n--) {
      *p++ = 0;
    }
  }
}

// BLE NotifyによるACK返信
void sendBleAck(const char* ackType, uint16_t sessionId, const char* detail = "") {
  if (pTxRxCharacteristic == nullptr || !isBleConnected) return;

  char message[64];
  if (strlen(detail) > 0) {
    snprintf(message, sizeof(message), "ACK:%u:%s:%s", sessionId, ackType, detail);
  } else {
    snprintf(message, sizeof(message), "ACK:%u:%s", sessionId, ackType);
  }

  pTxRxCharacteristic->setValue((uint8_t*)message, strlen(message));
  pTxRxCharacteristic->notify();
  delay(8);
}

// ============================================================================
// 緊急NumLock解除トグル送出
// 外部からの明示的コマンド CMD:NUM_UNLOCK 受信時のみ実行
// ============================================================================
void sendNumLockToggle() {
  KeyReport report;
  memset(&report, 0, sizeof(KeyReport));
  report.keys[0] = 0x53; // USB HID Usage 0x53 = NumLock
  Keyboard.sendReport(&report);
  delay(20);
  memset(&report, 0, sizeof(KeyReport));
  Keyboard.sendReport(&report);
  delay(20);
}

// ============================================================================
// JIS 109/106 キーボード対応 キーストローク送出エンジン
// 未定義コードや危険なスキャンコードは一切送出せず、安全なASCII記号補正のみを行う
// ============================================================================
void sendSafeChar(char c) {
  uint8_t uc = (uint8_t)c;
  
  if (uc < 32 || uc > 126) {
    if (c == '\b' || uc == 0x08) {
      Keyboard.write(KEY_BACKSPACE);
      delay(25);
      return;
    }
    if (c == '\t') {
      Keyboard.write(KEY_TAB);
      delay(12);
      return;
    }
    if (c == '\n') {
      Keyboard.write(KEY_RETURN);
      delay(20);
      return;
    }
    if (uc == 0x1B || uc == 0x11) { // ESC または 無変換・リセットコマンド
      Keyboard.write(KEY_ESC);
      delay(15);
      return;
    }
    return;
  }

  // Windows JIS 109キーボード配列向け記号補正
  switch (c) {
    case ':': // JISでは「'」キー位置 (0x27)
      Keyboard.write((char)0x27);
      break;
    case '@': // JISではバッククォートキー位置 (0x60)
      Keyboard.write((char)0x60);
      break;
    case '[': // JISでは「]」キー位置
      Keyboard.write(']');
      break;
    case ']': // JISでは「\」キー位置 (0x5C)
      Keyboard.write((char)0x5C);
      break;
    case '^': // JISでは「=」キー位置
      Keyboard.write('=');
      break;
    case '~': // JIS Shift + ^
      Keyboard.press(KEY_LEFT_SHIFT);
      Keyboard.press('=');
      delay(4);
      Keyboard.releaseAll();
      break;
    case '(': // JIS Shift + 8
      Keyboard.press(KEY_LEFT_SHIFT);
      Keyboard.press('8');
      delay(4);
      Keyboard.releaseAll();
      break;
    case ')': // JIS Shift + 9
      Keyboard.press(KEY_LEFT_SHIFT);
      Keyboard.press('9');
      delay(4);
      Keyboard.releaseAll();
      break;
    case '=': // JIS Shift + -
      Keyboard.press(KEY_LEFT_SHIFT);
      Keyboard.press('-');
      delay(4);
      Keyboard.releaseAll();
      break;
    case '"': // JIS Shift + 2
      Keyboard.press(KEY_LEFT_SHIFT);
      Keyboard.press('2');
      delay(4);
      Keyboard.releaseAll();
      break;
    case '\'': // JIS Shift + 7
      Keyboard.press(KEY_LEFT_SHIFT);
      Keyboard.press('7');
      delay(4);
      Keyboard.releaseAll();
      break;
    case '&': // JIS Shift + 6
      Keyboard.press(KEY_LEFT_SHIFT);
      Keyboard.press('6');
      delay(4);
      Keyboard.releaseAll();
      break;
    case '{': // JIS Shift + [
      Keyboard.press(KEY_LEFT_SHIFT);
      Keyboard.press(']');
      delay(4);
      Keyboard.releaseAll();
      break;
    case '}': // JIS Shift + ] (0x5C)
      Keyboard.press(KEY_LEFT_SHIFT);
      Keyboard.press((char)0x5C);
      delay(4);
      Keyboard.releaseAll();
      break;
    case '<': // JIS Shift + ,
      Keyboard.press(KEY_LEFT_SHIFT);
      Keyboard.press(',');
      delay(4);
      Keyboard.releaseAll();
      break;
    case '>': // JIS Shift + .
      Keyboard.press(KEY_LEFT_SHIFT);
      Keyboard.press('.');
      delay(4);
      Keyboard.releaseAll();
      break;
    case '?': // JIS Shift + /
      Keyboard.press(KEY_LEFT_SHIFT);
      Keyboard.press('/');
      delay(4);
      Keyboard.releaseAll();
      break;
    case '!': // JIS Shift + 1
      Keyboard.press(KEY_LEFT_SHIFT);
      Keyboard.press('1');
      delay(4);
      Keyboard.releaseAll();
      break;
    case '_': // JIS Shift + \ (ろ)
      Keyboard.press(KEY_LEFT_SHIFT);
      Keyboard.press((char)0x5C);
      delay(4);
      Keyboard.releaseAll();
      break;
    default:
      Keyboard.write(c);
      break;
  }
  delay(10); // 電子カルテ取りこぼし防止インターキー遅延 (10ms)
}

// ============================================================================
// Zero-RAM SPIFFS 二分探索エンジン
// RAM上に辞書を一括展開せず、f.seek()で必要なレコード（8B/32B）のみをスタック変数に読み出す
// ============================================================================

// 1. 難読単漢字テーブル (/kanji_f5.bin) 二分探索
bool lookupKanjiF5(File& f, uint16_t count, const char* utf8Char, uint16_t* outUnicode) {
  if (utf8Char == nullptr || count == 0 || !f) return false;

  char target[4] = {0, 0, 0, 0};
  size_t ulen = 0;
  while (utf8Char[ulen] != '\0' && ulen < 4) {
    target[ulen] = utf8Char[ulen];
    ulen++;
  }

  int32_t low = 0;
  int32_t high = (int32_t)count - 1;

  while (low <= high) {
    int32_t mid = low + (high - low) / 2;
    uint32_t offset = (uint32_t)sizeof(KanjiHeader) + (uint32_t)mid * (uint32_t)sizeof(KanjiRecord);

    if (!f.seek(offset, SeekSet)) break;

    KanjiRecord rec;
    if (f.read((uint8_t*)&rec, sizeof(KanjiRecord)) != sizeof(KanjiRecord)) break;

    int cmp = memcmp(target, rec.utf8, 4);
    if (cmp == 0) {
      if (outUnicode != nullptr) {
        *outUnicode = rec.unicode;
      }
      return true;
    } else if (cmp < 0) {
      high = mid - 1;
    } else {
      low = mid + 1;
    }
  }
  return false;
}

bool lookupKanjiF5(const char* utf8Char, uint16_t* outUnicode) {
  if (utf8Char == nullptr || !spiffsMounted) return false;

  File f = SPIFFS.open("/kanji_f5.bin", "r");
  if (!f) return false;

  KanjiHeader hdr;
  if (f.read((uint8_t*)&hdr, sizeof(KanjiHeader)) != sizeof(KanjiHeader)) {
    f.close();
    return false;
  }

  if (memcmp(hdr.magic, "KANJ", 4) != 0 || hdr.recordSize != sizeof(KanjiRecord) || hdr.count == 0) {
    f.close();
    return false;
  }

  bool found = lookupKanjiF5(f, hdr.count, utf8Char, outUnicode);
  f.close();
  return found;
}

// 2. 医療用語・カタカナ薬名打鍵テーブル (/med_terms.bin) 二分探索
bool lookupMedicalTerm(File& f, uint32_t count, const char* word, size_t len, MedTermRecord* outRec) {
  if (word == nullptr || len == 0 || count == 0 || !f) return false;

  uint32_t targetHash = calculateFnv1a32(word, len);

  int32_t low = 0;
  int32_t high = (int32_t)count - 1;

  while (low <= high) {
    int32_t mid = low + (high - low) / 2;
    uint32_t offset = (uint32_t)sizeof(TermHeader) + (uint32_t)mid * (uint32_t)sizeof(MedTermRecord);

    if (!f.seek(offset, SeekSet)) break;

    MedTermRecord rec;
    if (f.read((uint8_t*)&rec, sizeof(MedTermRecord)) != sizeof(MedTermRecord)) break;

    if (targetHash == rec.hash) {
      if (outRec != nullptr) {
        *outRec = rec;
      }
      return true;
    } else if (targetHash < rec.hash) {
      high = mid - 1;
    } else {
      low = mid + 1;
    }
  }
  return false;
}

bool lookupMedicalTerm(const char* word, size_t len, MedTermRecord* outRec) {
  if (word == nullptr || len == 0 || !spiffsMounted) return false;

  File f = SPIFFS.open("/med_terms.bin", "r");
  if (!f) return false;

  TermHeader hdr;
  if (f.read((uint8_t*)&hdr, sizeof(TermHeader)) != sizeof(TermHeader)) {
    f.close();
    return false;
  }

  if (memcmp(hdr.magic, "TERM", 4) != 0 || hdr.recordSize != sizeof(MedTermRecord) || hdr.count == 0) {
    f.close();
    return false;
  }

  bool found = lookupMedicalTerm(f, hdr.count, word, len, outRec);
  f.close();
  return found;
}

// 難読漢字のF5直接着弾（Unicode 16進4桁 + F5 + Enter）
// 一般漢字（0x4E00〜0x9FFF）への乱射を完全に防止し、ヒット時のみ実行
void sendKanjiF5Direct(uint16_t unicode) {
  char hexBuf[5];
  snprintf(hexBuf, sizeof(hexBuf), "%04X", unicode);
  for (int k = 0; k < 4; k++) {
    sendSafeChar(hexBuf[k]);
  }
  Keyboard.write(KEY_F5);
  delay(25);
  Keyboard.write(KEY_RETURN);
  delay(35);
}

// 医療用語・カタカナ薬名のモード別物理打鍵
void sendMedTermKeystrokes(const MedTermRecord& rec) {
  size_t rLen = rec.romajiLen;
  if (rLen > 25) rLen = 25;
  for (size_t r = 0; r < rLen; r++) {
    char rc = rec.romaji[r];
    if (rc == '\0') break;
    sendSafeChar(rc);
  }
  if (rec.mode == 2) {
    // Mode 2: カタカナ薬品名 (F7全角カタカナ強制 ➔ Enter確定)
    Keyboard.write(KEY_F7);
    delay(25);
    Keyboard.write(KEY_RETURN);
    delay(40);
  } else if (rec.mode == 3) {
    // Mode 3: 半角F10 (F10強制 ➔ Enter確定)
    Keyboard.write(KEY_F10);
    delay(20);
    Keyboard.write(KEY_RETURN);
    delay(40);
  } else {
    // Mode 1: 傷病名・医学用語 (Space漢字変換 ➔ Enter確定)
    Keyboard.write(' ');
    delay(30);
    Keyboard.write(KEY_RETURN);
    delay(40);
  }
}

// ============================================================================
// レベル4用 一般かな・約物テーブル＆フォールバック変換エンジン
// ============================================================================
struct KanaTableEntry {
  const char* kana;
  const char* romaji;
};

// 2文字かなダイグラフ (きゃ, しゅ, ちょ等: 6バイトUTF-8)
static const KanaTableEntry DIGRAPH_TABLE[] = {
  {"きゃ", "kya"}, {"きゅ", "kyu"}, {"きょ", "kyo"},
  {"しゃ", "sya"}, {"しゅ", "syu"}, {"しょ", "syo"},
  {"ちゃ", "tya"}, {"ちゅ", "tyu"}, {"ちょ", "tyo"},
  {"にゃ", "nya"}, {"にゅ", "nyu"}, {"にょ", "nyo"},
  {"ひゃ", "hya"}, {"ひゅ", "hyu"}, {"ひょ", "hyo"},
  {"みゃ", "mya"}, {"みゅ", "myu"}, {"みょ", "myo"},
  {"りゃ", "rya"}, {"りゅ", "ryu"}, {"りょ", "ryo"},
  {"ぎゃ", "gya"}, {"ぎゅ", "gyu"}, {"ぎょ", "gyo"},
  {"じゃ", "zya"}, {"じゅ", "zyu"}, {"じょ", "zyo"},
  {"びゃ", "bya"}, {"びゅ", "byu"}, {"びょ", "byo"},
  {"ぴゃ", "pya"}, {"ぴゅ", "pyu"}, {"ぴょ", "pyo"},
  {"ふぁ", "fa"},  {"ふぃ", "fi"},  {"ふぇ", "fe"},  {"ふぉ", "fo"},
  {"てぃ", "ti"},  {"でぃ", "di"},  {"ちぇ", "tye"}, {"しぇ", "sye"},
  {"キャ", "kya"}, {"キュ", "kyu"}, {"キョ", "kyo"},
  {"シャ", "sya"}, {"シュ", "syu"}, {"ショ", "syo"},
  {"チャ", "tya"}, {"チュ", "tyu"}, {"チョ", "tyo"},
  {"ニャ", "nya"}, {"ニュ", "nyu"}, {"ニョ", "nyo"},
  {"ヒャ", "hya"}, {"ヒュ", "hyu"}, {"ヒョ", "hyo"},
  {"ミャ", "mya"}, {"ミュ", "myu"}, {"ミョ", "myo"},
  {"リャ", "rya"}, {"リュ", "ryu"}, {"リョ", "ryo"},
  {"ギャ", "gya"}, {"ギュ", "gyu"}, {"ギョ", "gyo"},
  {"ジャ", "zya"}, {"ジュ", "zyu"}, {"ジョ", "zyo"},
  {"ビャ", "bya"}, {"ビュ", "byu"}, {"ビョ", "byo"},
  {"ピャ", "pya"}, {"ピュ", "pyu"}, {"ピョ", "pyo"},
  {"ファ", "fa"},  {"フィ", "fi"},  {"フェ", "fe"},  {"フォ", "fo"},
  {"ティ", "ti"},  {"ディ", "di"},  {"チェ", "tye"}, {"シェ", "sye"}
};

// 1文字かな (3バイトUTF-8)
static const KanaTableEntry MONO_KANA_TABLE[] = {
  {"あ", "a"},  {"い", "i"},  {"う", "u"},  {"え", "e"},  {"お", "o"},
  {"か", "ka"}, {"き", "ki"}, {"く", "ku"}, {"け", "ke"}, {"こ", "ko"},
  {"が", "ga"}, {"ぎ", "gi"}, {"ぐ", "gu"}, {"げ", "ge"}, {"ご", "go"},
  {"さ", "sa"}, {"し", "si"}, {"す", "su"}, {"せ", "se"}, {"そ", "so"},
  {"ざ", "za"}, {"じ", "zi"}, {"ず", "zu"}, {"ぜ", "ze"}, {"ぞ", "zo"},
  {"た", "ta"}, {"ち", "ti"}, {"つ", "tu"}, {"て", "te"}, {"と", "to"},
  {"だ", "da"}, {"ぢ", "di"}, {"づ", "du"}, {"で", "de"}, {"ど", "do"},
  {"な", "na"}, {"に", "ni"}, {"ぬ", "nu"}, {"ね", "ne"}, {"の", "no"},
  {"は", "ha"}, {"ひ", "hi"}, {"ふ", "hu"}, {"へ", "he"}, {"ほ", "ho"},
  {"ば", "ba"}, {"び", "bi"}, {"ぶ", "bu"}, {"べ", "be"}, {"ぼ", "bo"},
  {"ぱ", "pa"}, {"ぴ", "pi"}, {"ぷ", "pu"}, {"ぺ", "pe"}, {"ぽ", "po"},
  {"ま", "ma"}, {"み", "mi"}, {"む", "mu"}, {"め", "me"}, {"も", "mo"},
  {"や", "ya"}, {"ゆ", "yu"}, {"よ", "yo"},
  {"ら", "ra"}, {"り", "ri"}, {"る", "ru"}, {"れ", "re"}, {"ろ", "ro"},
  {"わ", "wa"}, {"を", "wo"}, {"ん", "nn"},
  {"っ", "ltu"}, {"ゃ", "xya"}, {"ゅ", "xyu"}, {"ょ", "xyo"},
  {"ぁ", "xa"},  {"ぃ", "xi"},  {"ぅ", "xu"},  {"ぇ", "xe"},  {"ぉ", "xo"},
  {"ゔ", "vu"},
  {"ア", "a"},  {"イ", "i"},  {"ウ", "u"},  {"エ", "e"},  {"オ", "o"},
  {"カ", "ka"}, {"キ", "ki"}, {"ク", "ku"}, {"ケ", "ke"}, {"コ", "ko"},
  {"ガ", "ga"}, {"ギ", "gi"}, {"グ", "gu"}, {"ゲ", "ge"}, {"ゴ", "go"},
  {"サ", "sa"}, {"シ", "si"}, {"ス", "su"}, {"セ", "se"}, {"ソ", "so"},
  {"ザ", "za"}, {"ジ", "zi"}, {"ズ", "zu"}, {"ゼ", "ze"}, {"ゾ", "zo"},
  {"タ", "ta"}, {"チ", "ti"}, {"ツ", "tu"}, {"テ", "te"}, {"ト", "to"},
  {"ダ", "da"}, {"ヂ", "di"}, {"ヅ", "du"}, {"デ", "de"}, {"ド", "do"},
  {"ナ", "na"}, {"ニ", "ni"}, {"ヌ", "nu"}, {"ネ", "ne"}, {"ノ", "no"},
  {"ハ", "ha"}, {"ヒ", "hi"}, {"フ", "hu"}, {"ヘ", "he"}, {"ホ", "ho"},
  {"バ", "ba"}, {"ビ", "bi"}, {"ブ", "bu"}, {"ベ", "be"}, {"ボ", "bo"},
  {"パ", "pa"}, {"ピ", "pi"}, {"プ", "pu"}, {"ペ", "pe"}, {"ポ", "po"},
  {"マ", "ma"}, {"ミ", "mi"}, {"ム", "mu"}, {"メ", "me"}, {"モ", "mo"},
  {"ヤ", "ya"}, {"ユ", "yu"}, {"ヨ", "yo"},
  {"ラ", "ra"}, {"リ", "ri"}, {"ル", "ru"}, {"レ", "re"}, {"ロ", "ro"},
  {"ワ", "wa"}, {"ヲ", "wo"}, {"ン", "nn"},
  {"ッ", "ltu"}, {"ャ", "xya"}, {"ュ", "xyu"}, {"ョ", "xyo"},
  {"ァ", "xa"},  {"ィ", "xi"},  {"ゥ", "xu"},  {"ェ", "xe"},  {"ォ", "xo"},
  {"ヴ", "vu"},  {"ー", "-"}
};

// UTF-8ひらがな判定 (U+3041〜U+3096)
bool isUtf8Hiragana(const char* s) {
  if (s == nullptr) return false;
  uint8_t c0 = (uint8_t)s[0];
  uint8_t c1 = (uint8_t)s[1];
  uint8_t c2 = (uint8_t)s[2];
  if (c0 == 0xE3) {
    if (c1 == 0x81 && c2 >= 0x81 && c2 <= 0xBF) return true;
    if (c1 == 0x82 && c2 >= 0x80 && c2 <= 0x96) return true;
  }
  return false;
}

// UTF-8カタカナ判定 (U+30A1〜U+30FA, ー: U+30FC)
bool isUtf8Katakana(const char* s) {
  if (s == nullptr) return false;
  uint8_t c0 = (uint8_t)s[0];
  uint8_t c1 = (uint8_t)s[1];
  uint8_t c2 = (uint8_t)s[2];
  if (c0 == 0xE3) {
    if (c1 == 0x82 && c2 >= 0xA1 && c2 <= 0xBF) return true;
    if (c1 == 0x83 && c2 >= 0x80 && c2 <= 0xBC) return true;
  }
  return false;
}

const char* findDigraphRomaji(const char* s) {
  for (size_t i = 0; i < sizeof(DIGRAPH_TABLE) / sizeof(KanaTableEntry); i++) {
    if (memcmp(s, DIGRAPH_TABLE[i].kana, 6) == 0) {
      return DIGRAPH_TABLE[i].romaji;
    }
  }
  return nullptr;
}

const char* findMonoKanaRomaji(const char* s) {
  for (size_t i = 0; i < sizeof(MONO_KANA_TABLE) / sizeof(KanaTableEntry); i++) {
    if (memcmp(s, MONO_KANA_TABLE[i].kana, 3) == 0) {
      return MONO_KANA_TABLE[i].romaji;
    }
  }
  return nullptr;
}

// ============================================================================
// 物理ボタンの単一エッジ検出 (GPIO 41, Active LOW)
// ============================================================================
static int btnLastReading = HIGH;
static uint32_t btnLastDebounceTime = 0;
static int btnStableState = HIGH;

void resetButtonState() {
  btnLastReading = HIGH;
  btnStableState = HIGH;
  btnLastDebounceTime = millis();
}

bool isFrontButtonPressed() {
  int reading = digitalRead(FRONT_BTN_PIN);

  if (reading != btnLastReading) {
    btnLastDebounceTime = millis();
  }
  btnLastReading = reading;

  if ((millis() - btnLastDebounceTime) > 35) { // 35msデバウンス
    if (reading != btnStableState) {
      btnStableState = reading;
      if (btnStableState == LOW) { // 立ち下がりエッジ（押下時）
        return true;
      }
    }
  }
  return false;
}

// スマートHVC（High Value Care: 高価値医療）スコア推論エンジン (0〜100点)
int calculateHvcScore(const char* text, size_t len) {
  if (text == nullptr || len == 0) return 70;

  int score = 70;
  if (strstr(text, "S:") || strstr(text, "O:") || strstr(text, "A:") || strstr(text, "P:") ||
      strstr(text, "主訴") || strstr(text, "現病歴") || strstr(text, "所見") || 
      strstr(text, "診断") || strstr(text, "方針") || strstr(text, "評価")) {
    score += 10;
  }
  if (strstr(text, "BP") || strstr(text, "HR") || strstr(text, "SpO2") || strstr(text, "BT") ||
      strstr(text, "PR") || strstr(text, "血圧") || strstr(text, "脈拍") || strstr(text, "体温") ||
      strstr(text, "mmHg") || strstr(text, "bpm") || strstr(text, "℃") || strstr(text, "%")) {
    score += 10;
  }
  if (strstr(text, "X-P") || strstr(text, "XP") || strstr(text, "ECG") || strstr(text, "CT") ||
      strstr(text, "MRI") || strstr(text, "US") || strstr(text, "HbA1c") || strstr(text, "CRP") ||
      strstr(text, "WBC") || strstr(text, "eGFR") || strstr(text, "Cr") || strstr(text, "心電図") ||
      strstr(text, "レントゲン") || strstr(text, "エコー") || strstr(text, "採血")) {
    score += 10;
  }
  if (score > 100) score = 100;
  if (score < 50) score = 50;
  return score;
}

// ============================================================================
// ★【4層ハイブリッド打鍵ディスパッチャー (Zero-RAM SPIFFS二分探索統合版)】
// レベル1: 半角ASCII（英数字・単位・数値・記号補正）➔ 無変換キー/直接打鍵
// レベル2: /med_terms.bin 最長一致 ➔ 辞書Modeに応じたF7強制またはSpace変換
// レベル3: /kanji_f5.bin 難読医療漢字 ➔ Unicode 4桁 + F5 + Enter
// レベル4: 一般ひらがな・熟語 ➔ ひらがな連続塊は即時Enter確定、一般語は最小形態素Space変換
// 生HIDパルスを完全排除し、一般漢字へのF5乱射（日時スタンプ誤挿入バグ）を100%防止
// ============================================================================
void dispatchSafeKeystrokes() {
  size_t i = 0;
  size_t total = currentMsg.actualTotalBytes;
  const char* buf = currentMsg.assembledBuffer;

  // SPIFFS辞書ファイルのオープン（打鍵セッション中のみファイルハンドルを保持）
  File fKanji;
  File fTerms;
  uint16_t kanjiCount = 0;
  uint32_t termCount = 0;

  if (spiffsMounted) {
    if (SPIFFS.exists("/kanji_f5.bin")) {
      fKanji = SPIFFS.open("/kanji_f5.bin", "r");
      if (fKanji) {
        KanjiHeader kh;
        if (fKanji.read((uint8_t*)&kh, sizeof(KanjiHeader)) == sizeof(KanjiHeader)) {
          if (memcmp(kh.magic, "KANJ", 4) == 0 && kh.recordSize == sizeof(KanjiRecord)) {
            kanjiCount = kh.count;
          }
        }
      }
    }
    if (SPIFFS.exists("/med_terms.bin")) {
      fTerms = SPIFFS.open("/med_terms.bin", "r");
      if (fTerms) {
        TermHeader th;
        if (fTerms.read((uint8_t*)&th, sizeof(TermHeader)) == sizeof(TermHeader)) {
          if (memcmp(th.magic, "TERM", 4) == 0 && th.recordSize == sizeof(MedTermRecord)) {
            termCount = th.count;
          }
        }
      }
    }
  }

  while (i < total) {
    char c = buf[i];

    // ------------------------------------------------------------------------
    // A. 改行処理 (CRLF / LF)
    // ------------------------------------------------------------------------
    if (c == '\r') {
      if (i + 1 < total && buf[i + 1] == '\n') i++;
      Keyboard.write(KEY_RETURN);
      delay(22);
      i++;
      continue;
    }
    if (c == '\n') {
      Keyboard.write(KEY_RETURN);
      delay(22);
      i++;
      continue;
    }

    // ------------------------------------------------------------------------
    // B. 明示的制御タグの高速解析 ([K], [H], [Z], [A], [U], etc.)
    // ------------------------------------------------------------------------
    // 1. [K]...[/K] (カタカナモード: F7 ➔ Enter)
    if (strncmp(&buf[i], "[K]", 3) == 0 || strncmp(&buf[i], "<K>", 3) == 0) {
      i += 3;
      while (i < total) {
        if (strncmp(&buf[i], "[/K]", 4) == 0 || strncmp(&buf[i], "</K>", 4) == 0) {
          i += 4;
          break;
        }
        if (buf[i] == '[' || buf[i] == '<' || buf[i] == '\n' || buf[i] == '\r') {
          break;
        }
        char rc = buf[i];
        if (rc != ' ') {
          sendSafeChar(rc);
        }
        i++;
      }
      Keyboard.write(KEY_F7);
      delay(25);
      Keyboard.write(KEY_RETURN);
      delay(40);
      continue;
    }

    // 2. [H]...[/H] (ひらがな助詞モード: Enter即時確定、Space禁止)
    if (strncmp(&buf[i], "[H]", 3) == 0 || strncmp(&buf[i], "<H>", 3) == 0) {
      i += 3;
      while (i < total) {
        if (strncmp(&buf[i], "[/H]", 4) == 0 || strncmp(&buf[i], "</H>", 4) == 0) {
          i += 4;
          break;
        }
        if (strncmp(&buf[i], "[K]", 3) == 0 || strncmp(&buf[i], "[H]", 3) == 0 || 
            strncmp(&buf[i], "[Z]", 3) == 0 || strncmp(&buf[i], "[A]", 3) == 0 || 
            strncmp(&buf[i], "[/", 2) == 0 || buf[i] == '\n' || buf[i] == '\r') {
          break;
        }
        char rc = buf[i];
        if (rc != ' ') {
          sendSafeChar(rc);
        }
        i++;
      }
      Keyboard.write(KEY_RETURN);
      delay(40);
      continue;
    }

    // 3. [Z]...[/Z] (漢字変換モード: Space変換 ➔ Enter確定)
    if (strncmp(&buf[i], "[Z]", 3) == 0 || strncmp(&buf[i], "<Z>", 3) == 0) {
      i += 3;
      while (i < total) {
        if (strncmp(&buf[i], "[/Z]", 4) == 0 || strncmp(&buf[i], "</Z>", 4) == 0) {
          i += 4;
          break;
        }
        if (strncmp(&buf[i], "[K]", 3) == 0 || strncmp(&buf[i], "[H]", 3) == 0 || 
            strncmp(&buf[i], "[Z]", 3) == 0 || strncmp(&buf[i], "[A]", 3) == 0 || 
            strncmp(&buf[i], "[/", 2) == 0 || buf[i] == '\n' || buf[i] == '\r') {
          break;
        }
        char rc = buf[i];
        if (rc != ' ') {
          sendSafeChar(rc);
        }
        i++;
      }
      Keyboard.write(' ');
      delay(30);
      Keyboard.write(KEY_RETURN);
      delay(40);
      continue;
    }

    // 4. [A]...[/A] (半角ASCIIモード: F10強制 ➔ Enter確定)
    if (strncmp(&buf[i], "[A]", 3) == 0 || strncmp(&buf[i], "<A>", 3) == 0) {
      i += 3;
      while (i < total) {
        if (strncmp(&buf[i], "[/A]", 4) == 0 || strncmp(&buf[i], "</A>", 4) == 0) {
          i += 4;
          break;
        }
        if (strncmp(&buf[i], "[K]", 3) == 0 || strncmp(&buf[i], "[H]", 3) == 0 || 
            strncmp(&buf[i], "[Z]", 3) == 0 || strncmp(&buf[i], "[A]", 3) == 0 || 
            strncmp(&buf[i], "[/", 2) == 0 || buf[i] == '\n' || buf[i] == '\r') {
          break;
        }
        sendSafeChar(buf[i]);
        i++;
      }
      Keyboard.write(KEY_F10);
      delay(20);
      Keyboard.write(KEY_RETURN);
      delay(40);
      continue;
    }

    // 5. [U]...[/U] (明示的Unicode F5タグ: 4桁16進 ➔ F5 ➔ Enter)
    if (strncmp(&buf[i], "[U]", 3) == 0 || strncmp(&buf[i], "<U>", 3) == 0) {
      i += 3;
      char hexCode[5] = {0};
      int hexLen = 0;
      while (i < total) {
        if (strncmp(&buf[i], "[/U]", 4) == 0 || strncmp(&buf[i], "</U>", 4) == 0) {
          i += 4;
          break;
        }
        if (buf[i] == '[' || buf[i] == '<' || buf[i] == '\n' || buf[i] == '\r') {
          break;
        }
        if (hexLen < 4 && isxdigit(buf[i])) {
          hexCode[hexLen++] = toupper(buf[i]);
        }
        i++;
      }
      if (hexLen == 4) {
        for (int k = 0; k < 4; k++) {
          sendSafeChar(hexCode[k]);
        }
        Keyboard.write(KEY_F5);
        delay(25);
        Keyboard.write(KEY_RETURN);
        delay(35);
      }
      continue;
    }

    // 6. 閉じタグの安全消費および補助キーコード (<ENTER>, <SPACE>, [BS] 等)
    if (c == '<' || c == '[') {
      if (strncmp(&buf[i], "[BS]", 4) == 0 || strncmp(&buf[i], "<BS>", 4) == 0) {
        Keyboard.write(KEY_BACKSPACE);
        delay(15);
        i += 4;
        continue;
      }
      if (strncmp(&buf[i], "[/K]", 4) == 0 || strncmp(&buf[i], "</K>", 4) == 0) { i += 4; continue; }
      if (strncmp(&buf[i], "[/H]", 4) == 0 || strncmp(&buf[i], "</H>", 4) == 0) { i += 4; continue; }
      if (strncmp(&buf[i], "[/Z]", 4) == 0 || strncmp(&buf[i], "</Z>", 4) == 0) { i += 4; continue; }
      if (strncmp(&buf[i], "[/A]", 4) == 0 || strncmp(&buf[i], "</A>", 4) == 0) { i += 4; continue; }
      if (strncmp(&buf[i], "[/U]", 4) == 0 || strncmp(&buf[i], "</U>", 4) == 0) { i += 4; continue; }
      if (strncmp(&buf[i], "<ENTER>", 7) == 0 || strncmp(&buf[i], "[ENTER]", 7) == 0) {
        Keyboard.write(KEY_RETURN);
        delay(22);
        i += 7;
        continue;
      }
      if (strncmp(&buf[i], "<CONV>", 6) == 0) {
        Keyboard.write(' ');
        delay(18);
        i += 6;
        continue;
      }
      if (strncmp(&buf[i], "<SPACE>", 7) == 0 || strncmp(&buf[i], "[SPACE]", 7) == 0) {
        Keyboard.write(' ');
        delay(15);
        i += 7;
        continue;
      }
      if (strncmp(&buf[i], "<IME_ON>", 8) == 0) { i += 8; continue; }
      if (strncmp(&buf[i], "<IME_OFF>", 9) == 0) { i += 9; continue; }
      if (strncmp(&buf[i], "[N]", 3) == 0 || strncmp(&buf[i], "<N>", 3) == 0) { i += 3; continue; }
    }

    // ------------------------------------------------------------------------
    // C. レベル1: 半角ASCII（英数字・単位・数値・記号補正）➔ 無変換キー/直接打鍵
    // ------------------------------------------------------------------------
    if ((uint8_t)c < 0x80) {
      sendSafeChar(c);
      i++;
      continue;
    }

    // ------------------------------------------------------------------------
    // D. マルチバイトUTF-8処理 (レベル2, レベル3, レベル4)
    // ------------------------------------------------------------------------

    // 【レベル2】: /med_terms.bin に合致する医薬品・傷病名の最長一致判定 (Zero-RAM二分探索)
    bool termMatched = false;
    if (fTerms && termCount > 0) {
      // 現在位置からタグ・改行・終端に達するまでのUTF-8文字境界を最大48バイト分収集
      size_t candOffsets[16];
      size_t candCount = 0;
      size_t scanIdx = i;

      while (scanIdx < total && candCount < 16) {
        char sc = buf[scanIdx];
        if (sc == '[' || sc == '<' || sc == '\r' || sc == '\n' || (uint8_t)sc < 0x80) {
          break;
        }
        size_t uLen = getUtf8CharLen((uint8_t)sc);
        if (scanIdx + uLen > total) break;
        scanIdx += uLen;
        size_t curLen = scanIdx - i;
        if (curLen >= 6) { // 医療用語は最短2文字 (6バイト以上)
          candOffsets[candCount++] = curLen;
        }
        if (curLen >= 48) break;
      }

      // 最長一致判定: 長い候補から順に二分探索
      for (int k = (int)candCount - 1; k >= 0; k--) {
        size_t testLen = candOffsets[k];
        MedTermRecord termRec;
        if (lookupMedicalTerm(fTerms, termCount, &buf[i], testLen, &termRec)) {
          sendMedTermKeystrokes(termRec);
          i += testLen;
          termMatched = true;
          break;
        }
      }
    }
    if (termMatched) {
      continue;
    }

    // 【レベル3】: /kanji_f5.bin に合致する難読医療漢字（嚥、瘻、褥、瘡等）➔ Unicode 4桁 + F5 + Enter
    size_t uLen = getUtf8CharLen((uint8_t)buf[i]);
    if (i + uLen <= total) {
      char utf8Single[5] = {0, 0, 0, 0, 0};
      memcpy(utf8Single, &buf[i], uLen);

      uint16_t unicodeVal = 0;
      if (fKanji && kanjiCount > 0 && lookupKanjiF5(fKanji, kanjiCount, utf8Single, &unicodeVal)) {
        // ヒット時のみ限定着弾（一般漢字へのF5乱射を完全に阻止）
        sendKanjiF5Direct(unicodeVal);
        i += uLen;
        continue;
      }
    }

    // 【レベル4】: 上記以外の一般ひらがな・カタカナ・約物・一般語
    // 1. 全角約物・記号の変換
    if (uLen == 3) {
      if (memcmp(&buf[i], "、", 3) == 0) { sendSafeChar(','); i += 3; continue; }
      if (memcmp(&buf[i], "。", 3) == 0) { sendSafeChar('.'); i += 3; continue; }
      if (memcmp(&buf[i], "・", 3) == 0) { sendSafeChar('/'); i += 3; continue; }
      if (memcmp(&buf[i], "「", 3) == 0) { sendSafeChar('['); i += 3; continue; }
      if (memcmp(&buf[i], "」", 3) == 0) { sendSafeChar(']'); i += 3; continue; }
      if (memcmp(&buf[i], "（", 3) == 0) { sendSafeChar('('); i += 3; continue; }
      if (memcmp(&buf[i], "）", 3) == 0) { sendSafeChar(')'); i += 3; continue; }
      if (memcmp(&buf[i], "〜", 3) == 0) { sendSafeChar('~'); i += 3; continue; }
      if (memcmp(&buf[i], "：", 3) == 0) { sendSafeChar(':'); i += 3; continue; }
      if (memcmp(&buf[i], "ー", 3) == 0) { sendSafeChar('-'); i += 3; continue; }
    }

    // 2. ひらがな連続塊: ローマ字送出 ➔ 即時Enter確定 (Space禁止！漢字巻き込みゼロ)
    if (isUtf8Hiragana(&buf[i])) {
      while (i < total && isUtf8Hiragana(&buf[i])) {
        // 2文字ダイグラフ判定 (きゃ, しゅ, ちょ等: 6バイト)
        if (i + 6 <= total) {
          const char* romajiDi = findDigraphRomaji(&buf[i]);
          if (romajiDi != nullptr) {
            for (const char* p = romajiDi; *p != '\0'; p++) {
              sendSafeChar(*p);
            }
            i += 6;
            continue;
          }
        }
        // 1文字かな判定 (3バイト)
        if (i + 3 <= total) {
          const char* romajiMo = findMonoKanaRomaji(&buf[i]);
          if (romajiMo != nullptr) {
            for (const char* p = romajiMo; *p != '\0'; p++) {
              sendSafeChar(*p);
            }
            i += 3;
            continue;
          }
        }
        i += getUtf8CharLen((uint8_t)buf[i]);
      }
      // ひらがな塊末尾で即時Enter確定
      Keyboard.write(KEY_RETURN);
      delay(35);
      continue;
    }

    // 3. カタカナ連続塊: ローマ字送出 ➔ F7全角カタカナ強制 ➔ Enter確定
    if (isUtf8Katakana(&buf[i])) {
      while (i < total && isUtf8Katakana(&buf[i])) {
        if (i + 6 <= total) {
          const char* romajiDi = findDigraphRomaji(&buf[i]);
          if (romajiDi != nullptr) {
            for (const char* p = romajiDi; *p != '\0'; p++) {
              sendSafeChar(*p);
            }
            i += 6;
            continue;
          }
        }
        if (i + 3 <= total) {
          const char* romajiMo = findMonoKanaRomaji(&buf[i]);
          if (romajiMo != nullptr) {
            for (const char* p = romajiMo; *p != '\0'; p++) {
              sendSafeChar(*p);
            }
            i += 3;
            continue;
          }
        }
        i += getUtf8CharLen((uint8_t)buf[i]);
      }
      Keyboard.write(KEY_F7);
      delay(25);
      Keyboard.write(KEY_RETURN);
      delay(40);
      continue;
    }

    // 4. 未登録の一般漢字・未分類文字 (フォールバック: F5乱射は絶対に行わず安全にスキップ)
    i += (uLen > 0 ? uLen : 1);
  }

  // ファイルハンドルのクローズ
  if (fKanji) fKanji.close();
  if (fTerms) fTerms.close();
}

// ============================================================================
// USB打鍵ディスパッチャー
// ============================================================================
void dispatchOutput() {
  if (currentMsg.actualTotalBytes == 0) return;

  if (!tud_mounted()) {
    currentState = STATE_USB_NOT_READY;
    setLedColor(64, 0, 64); // 紫色点灯（USB未接続警告）
    sendBleAck("ERR_USB_NOT_READY", currentMsg.sessionId);
    return;
  }

  currentState = STATE_TYPING;
  setLedColor(64, 0, 0); // 打鍵中: 赤色点灯
  sendBleAck("DISPATCH_STARTED", currentMsg.sessionId);

  // 4層ハイブリッド安全キーストローク送出（SPIFFS二分探索 Zero-RAM）
  dispatchSafeKeystrokes();

  // キーの完全開放
  Keyboard.releaseAll();
  sendBleAck("USB_REPORTS_SENT", currentMsg.sessionId);
  delay(30);

  // スマートHVCスコア推論
  int hvcScore = calculateHvcScore(currentMsg.assembledBuffer, currentMsg.actualTotalBytes);
  char hvcAck[32];
  const char* hvcGrade = (hvcScore >= 85) ? "EXCELLENT" : (hvcScore >= 70 ? "GOOD" : "REVIEW");
  snprintf(hvcAck, sizeof(hvcAck), "%d:%s", hvcScore, hvcGrade);
  sendBleAck("HVC_SCORE", currentMsg.sessionId, hvcAck);

  if (hvcScore >= 85) {
    setLedColor(0, 128, 64); // エメラルドグリーン
  } else if (hvcScore >= 70) {
    setLedColor(0, 96, 96);  // シアン
  } else {
    setLedColor(96, 96, 0);  // イエロー
  }
  delay(600);

  // セキュア消去
  secureWipeMessageContext();
  drainBleQueue();
  resetButtonState();

  currentState = isBleConnected ? STATE_BLE_CONNECTED : STATE_WAITING_BLE;
  if (isBleConnected) {
    setLedColor(0, 64, 0); // 緑点灯
  } else {
    setLedColor(0, 0, 64); // 青点灯
  }
}

// ============================================================================
// BLE コールバック実装
// ============================================================================
class MyServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* pServer) override {
    isBleConnected = true;
    currentState = STATE_BLE_CONNECTED;
    setLedColor(0, 64, 0); // 接続完了: 緑点灯
  }

  void onDisconnect(BLEServer* pServer) override {
    isBleConnected = false;
    currentState = STATE_WAITING_BLE;
    drainBleQueue();
    secureWipeMessageContext();
    Keyboard.releaseAll();
    setLedColor(0, 0, 64); // 待機状態: 青点灯
  }
};

class MyCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) override {
    uint8_t* pData = pCharacteristic->getData();
    size_t len = pCharacteristic->getLength();

    if (len > 0 && bleQueue != nullptr) {
      if (len > BLE_CHUNK_SIZE) {
        return;
      }

      BleQueueItem item;
      item.length = (uint16_t)len;
      memcpy(item.data, pData, len);

      xQueueSend(bleQueue, &item, 0);
    }
  }
};

// ============================================================================
// Arduino setup()
// ============================================================================
void setup() {
  pinMode(RGB_LED_PIN, OUTPUT);
  pinMode(FRONT_BTN_PIN, INPUT_PULLUP);

  setLedColor(0, 0, 64); // 青色（起動中）

  // SPIFFS初期化 (フォーマットフラグ: true)
  spiffsMounted = SPIFFS.begin(true);

  Keyboard.begin();
  USB.begin();

  bleQueue = xQueueCreate(BLE_QUEUE_SIZE, sizeof(BleQueueItem));

  BLEDevice::init("EHR-AI-Dongle");
  BLEDevice::setMTU(517);

  pBleServer = BLEDevice::createServer();
  pBleServer->setCallbacks(new MyServerCallbacks());

  BLEService *pService = pBleServer->createService(SERVICE_UUID);
  pTxRxCharacteristic = pService->createCharacteristic(
    CHARACTERISTIC_UUID,
    BLECharacteristic::PROPERTY_READ |
    BLECharacteristic::PROPERTY_WRITE | 
    BLECharacteristic::PROPERTY_WRITE_NR |
    BLECharacteristic::PROPERTY_NOTIFY
  );
  pTxRxCharacteristic->setCallbacks(new MyCallbacks());

  BLE2902* pBle2902 = new BLE2902();
  pBle2902->setNotifications(true);
  pTxRxCharacteristic->addDescriptor(pBle2902);

  pService->start();

  BLEAdvertisementData oAdvertisementData;
  oAdvertisementData.setFlags(0x06);
  oAdvertisementData.setName("EHR-AI-Dongle");

  BLEAdvertisementData oScanResponseData;
  oScanResponseData.setCompleteServices(BLEUUID(SERVICE_UUID));

  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->setAdvertisementData(oAdvertisementData);
  pAdvertising->setScanResponseData(oScanResponseData);
  pAdvertising->setScanResponse(true);
  pAdvertising->setMinPreferred(0x0C);
  pAdvertising->setMaxPreferred(0x18);
  pAdvertising->start();

  secureWipeMessageContext();
  resetButtonState();
  Keyboard.releaseAll();
  lastUsbState = tud_mounted();
  setLedColor(0, 0, 64); // 青色（BLE接続待機中）
}

// ============================================================================
// Arduino loop()
// ============================================================================
void loop() {
  // 0. BLE切断後の安全な再アドバタイズ処理
  static bool oldBleConnected = false;
  if (!isBleConnected && oldBleConnected) {
    delay(200);
    if (pBleServer != nullptr) {
      BLEDevice::startAdvertising();
    }
    oldBleConnected = isBleConnected;
  }
  if (isBleConnected && !oldBleConnected) {
    oldBleConnected = isBleConnected;
  }

  // 1. USBマウント状態のリアルタイム監視とBLE同期通知
  bool currentUsbState = tud_mounted();
  if (currentUsbState != lastUsbState) {
    lastUsbState = currentUsbState;
    if (currentUsbState) {
      sendBleAck("USB_MOUNTED", 0);
      if (currentState == STATE_USB_NOT_READY) {
        currentState = isBleConnected ? STATE_BLE_CONNECTED : STATE_WAITING_BLE;
        setLedColor(0, isBleConnected ? 64 : 0, isBleConnected ? 0 : 64);
      }
    } else {
      sendBleAck("USB_UNMOUNTED", 0);
      if (currentState != STATE_USB_NOT_READY && !isBleConnected) {
        currentState = STATE_USB_NOT_READY;
        setLedColor(64, 0, 64);
      }
    }
  }

  // 2. 受信キュー処理（バイナリパケット & 遠隔制御コマンド）
  BleQueueItem item;
  while (xQueueReceive(bleQueue, &item, 0) == pdTRUE) {

    // A. 遠隔制御コマンド (CMD:...) の解析
    if (item.length >= 4 && item.data[0] == 'C' && item.data[1] == 'M' && item.data[2] == 'D' && item.data[3] == ':') {
      char cmdBuf[64];
      size_t copyLen = item.length < sizeof(cmdBuf) - 1 ? item.length : sizeof(cmdBuf) - 1;
      memcpy(cmdBuf, item.data, copyLen);
      cmdBuf[copyLen] = '\0';

      // 1. 緊急NumLock解除トグル
      if (strcmp(cmdBuf, "CMD:NUM_UNLOCK") == 0) {
        sendNumLockToggle();
        sendBleAck("NUM_UNLOCKED", 0, "OK");
        continue;
      }

      // 2. リモート打鍵トリガー
      if (strcmp(cmdBuf, "CMD:TRIGGER") == 0) {
        if (currentState == STATE_READY_TO_TYPE) {
          sendBleAck("REMOTE_TRIGGER_ACCEPTED", currentMsg.sessionId);
          dispatchOutput();
        } else {
          sendBleAck("ERR_NOT_READY_TO_TYPE", currentMsg.sessionId);
        }
        continue;
      }

      // 3. BLE Ping & 疎通確認 (RTT計測)
      if (strncmp(cmdBuf, "CMD:PING:", 9) == 0) {
        const char* ts = cmdBuf + 9;
        sendBleAck("PONG", 0, ts);
        setLedColor(64, 64, 64); delay(30);
        if (currentState == STATE_BLE_CONNECTED) setLedColor(0, 64, 0);
        else if (currentState == STATE_READY_TO_TYPE) setLedColor(64, 64, 0);
        else setLedColor(0, 0, 64);
        continue;
      }

      // 4. 遠隔セキュアメモリゼロクリア (WIPE)
      if (strcmp(cmdBuf, "CMD:WIPE") == 0) {
        secureWipeMessageContext();
        drainBleQueue();
        Keyboard.releaseAll();
        currentState = isBleConnected ? STATE_BLE_CONNECTED : STATE_WAITING_BLE;
        setLedColor(0, isBleConnected ? 64 : 0, isBleConnected ? 0 : 64);
        sendBleAck("WIPED", 0);
        continue;
      }

      // 5. LEDテスト発光
      if (strcmp(cmdBuf, "CMD:LED_TEST") == 0) {
        setLedColor(64, 0, 0); delay(100);
        setLedColor(0, 64, 0); delay(100);
        setLedColor(0, 0, 64); delay(100);
        setLedColor(64, 64, 0); delay(100);
        if (currentState == STATE_BLE_CONNECTED) setLedColor(0, 64, 0);
        else if (currentState == STATE_READY_TO_TYPE) setLedColor(64, 64, 0);
        else setLedColor(0, 0, 64);
        sendBleAck("LED_TEST_OK", 0);
        continue;
      }

      // 6. ステータス問い合わせ
      if (strcmp(cmdBuf, "CMD:STATUS") == 0) {
        char statusDetail[48];
        snprintf(statusDetail, sizeof(statusDetail), "%d,%s,%u/%u", 
          currentState, tud_mounted() ? "USB_OK" : "USB_NO", 
          currentMsg.receivedCount, currentMsg.totalPackets);
        sendBleAck("STATUS_RESP", currentMsg.sessionId, statusDetail);
        continue;
      }
    }

    // B. セッション初期化フレーム (8バイト)
    if (item.length == sizeof(SessionInitHeader)) {
      uint16_t sid = readUint16LE(item.data);
      uint8_t totPkts = item.data[2];
      uint16_t totBytes = readUint16LE(item.data + 3);
      uint16_t totCrc = readUint16LE(item.data + 5);

      if (totPkts == 0 || totPkts > MAX_PACKETS || totBytes == 0 || totBytes > MAX_PAYLOAD_SIZE) {
        sendBleAck("ERR_INIT_PARAMS", sid);
        currentState = STATE_ERROR;
        setLedColor(64, 16, 0);
        continue;
      }

      secureWipeMessageContext();
      resetButtonState();
      Keyboard.releaseAll();
      currentMsg.sessionId = sid;
      currentMsg.totalPackets = totPkts;
      currentMsg.expectedTotalBytes = totBytes;
      currentMsg.expectedTotalCrc = totCrc;
      currentMsg.lastActivityTime = millis();
      currentMsg.retryAttempts = 0;
      currentState = STATE_RECEIVING;
      setLedColor(0, 48, 64); // シアン点灯（パケット受信中）
      sendBleAck("SESSION_READY", sid);
      continue;
    }

    // C. データスロットフレーム (ヘッダ8バイト + ペイロード)
    if (item.length >= sizeof(SlotHeader)) {
      uint16_t sid = readUint16LE(item.data);
      uint8_t seqNo = item.data[2];
      uint8_t mode = item.data[3];
      uint16_t payloadLen = readUint16LE(item.data + 4);
      uint16_t chunkCrc = readUint16LE(item.data + 6);
      uint8_t* payload = item.data + sizeof(SlotHeader);
      size_t actualLen = item.length - sizeof(SlotHeader);

      if (currentState != STATE_RECEIVING || currentMsg.sessionId != sid) {
        continue;
      }

      if (seqNo >= currentMsg.totalPackets || payloadLen != actualLen || payloadLen > MAX_PACKET_LEN) {
        sendBleAck("ERR_SLOT_HEADER", sid);
        continue;
      }

      if (calculateCrc16(payload, payloadLen) != chunkCrc) {
        sendBleAck("ERR_CHUNK_CRC", sid);
        continue;
      }

      // スロット格納
      if (!currentMsg.slots[seqNo].received) {
        currentMsg.slots[seqNo].len = payloadLen;
        memcpy(currentMsg.slots[seqNo].payload, payload, payloadLen);
        currentMsg.slots[seqNo].received = true;
        currentMsg.receivedCount++;
        currentMsg.mode = mode;
        currentMsg.lastActivityTime = millis();
      }

      // 全スロット受信完了判定
      if (currentMsg.receivedCount == currentMsg.totalPackets) {
        size_t offset = 0;
        bool bufferOverflow = false;

        for (uint8_t slotIdx = 0; slotIdx < currentMsg.totalPackets; slotIdx++) {
          if (offset + currentMsg.slots[slotIdx].len > MAX_PAYLOAD_SIZE) {
            bufferOverflow = true;
            break;
          }
          memcpy(currentMsg.assembledBuffer + offset, currentMsg.slots[slotIdx].payload, currentMsg.slots[slotIdx].len);
          offset += currentMsg.slots[slotIdx].len;
        }

        if (bufferOverflow || offset != currentMsg.expectedTotalBytes) {
          sendBleAck("ERR_LEN_MISMATCH", currentMsg.sessionId);
          secureWipeMessageContext();
          currentState = STATE_ERROR;
          setLedColor(64, 16, 0);
          break;
        }

        currentMsg.assembledBuffer[offset] = '\0';
        currentMsg.actualTotalBytes = offset;

        // 全体CRC16検証
        if (calculateCrc16((uint8_t*)currentMsg.assembledBuffer, offset) != currentMsg.expectedTotalCrc) {
          sendBleAck("ERR_TOTAL_CRC", currentMsg.sessionId);
          secureWipeMessageContext();
          currentState = STATE_ERROR;
          setLedColor(64, 16, 0);
          break;
        }

        // 全パケット完全受信・CRC一致：ボタン待機へ遷移し、黄色LED点灯
        resetButtonState();
        currentState = STATE_READY_TO_TYPE;
        setLedColor(64, 64, 0); // 黄色点灯（医師の物理ボタン押下待機）
        sendBleAck("ALL_PACKETS_READY", currentMsg.sessionId);
      }
    }
  }

  // 3. 受信タイムアウトと欠落パケット再送要求 (RETRY)
  if (currentState == STATE_RECEIVING && currentMsg.receivedCount < currentMsg.totalPackets) {
    if (millis() - currentMsg.lastActivityTime > RX_TIMEOUT_MS) {
      if (currentMsg.retryAttempts < MAX_RETRY_COUNT) {
        currentMsg.retryAttempts++;
        uint16_t missingBitmap = 0;
        for (uint8_t pIdx = 0; pIdx < currentMsg.totalPackets; pIdx++) {
          if (!currentMsg.slots[pIdx].received) {
            missingBitmap |= (1 << pIdx);
          }
        }
        char bitmapHex[10];
        snprintf(bitmapHex, sizeof(bitmapHex), "0x%04X", missingBitmap);
        sendBleAck("RETRY", currentMsg.sessionId, bitmapHex);
        currentMsg.lastActivityTime = millis();
      } else {
        sendBleAck("ERR_TIMEOUT_ABORT", currentMsg.sessionId);
        secureWipeMessageContext();
        drainBleQueue();
        Keyboard.releaseAll();
        currentState = isBleConnected ? STATE_BLE_CONNECTED : STATE_WAITING_BLE;
        setLedColor(0, isBleConnected ? 64 : 0, isBleConnected ? 0 : 64);
      }
    }
  }

  // 4. 物理ボタン押下の判定 (GPIO 41, Active LOW)
  if (currentState == STATE_READY_TO_TYPE) {
    setLedColor(64, 64, 0); // 黄色点灯維持
    if (isFrontButtonPressed()) {
      sendBleAck("PHYSICAL_BTN_PRESSED", currentMsg.sessionId);
      dispatchOutput(); // ボタン押下でカルテへ安全打鍵送出
    }
  }

  // 5. LED状態の維持とエラー時自動復帰
  if (currentState == STATE_WAITING_BLE) {
    setLedColor(0, 0, 64);
  } else if (currentState == STATE_BLE_CONNECTED) {
    setLedColor(0, 64, 0);
  } else if (currentState == STATE_ERROR) {
    static uint32_t errStartTime = 0;
    if (errStartTime == 0) errStartTime = millis();
    if (millis() - errStartTime > 1500) {
      errStartTime = 0;
      currentState = isBleConnected ? STATE_BLE_CONNECTED : STATE_WAITING_BLE;
      setLedColor(0, isBleConnected ? 64 : 0, isBleConnected ? 0 : 64);
    }
  }

  delay(10);
}
